from .product_views import *
from .goods_receipt_note_views import *
from .purchase_order_views import *
from .company_views import *
from .vendor_views import *
from .consumer_views import *
from .sales_order_views import *
from .history_views import *