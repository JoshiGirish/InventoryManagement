from django.apps import AppConfig


class InvmanageConfig(AppConfig):
    name = 'InvManage'
